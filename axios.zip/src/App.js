import logo from './logo.svg';
import './App.css';
import Fetch from './componet/Fetch';

function App() {
  return (
    <>
      {/* json data  (by default josn wrok) 
      Http methods. ( many http methods)
      .then()  (only use one time )
      error handling (better for es6) */}

      <Fetch/>
    </>
  );
}

export default App;
