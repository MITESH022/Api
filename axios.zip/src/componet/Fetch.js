import React, { useState } from 'react'
import axios from 'axios';
const Fetch = () => {

    const [news,setNews] = useState([])

    const fetchnews =()=> {

        console.log("clicked");

        axios.get("https://jsonplaceholder.typicode.com/photos")
        .then((response)=>{
             console.log(response);
             setNews(response.data) 
        })
    }


  return (
    <>

            <div className='container mb-5'>
            <div className='row'>
                <div className='col-4'>
                     <button className='btn btn-primary' onClick={fetchnews}>Fetch news</button>
                </div>
            </div>
            </div>
    

            <div className="container">
            <div className='row'>
                {

                    news.map((value)=> {

                        const {title,thumbnailUrl,id} = value
                        
                        return(
                            <div className='col-4' key={id}>

                            <div className="card" style={{width: "18rem"}} >
              <img src={thumbnailUrl} className="card-img-top" alt="..."/>
              <div className="card-body">
                <h5 className="card-title">{title}</h5>
                <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" className="btn btn-primary">Go somewhere</a>
              </div>
            </div>
            </div>
                        );
                    })
                }
                </div>
            </div>
        
    </>
  )
}

export default Fetch;